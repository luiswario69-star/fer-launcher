package com.espejo.launcher

import android.content.Context
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.RectF
import android.util.AttributeSet
import android.view.View
import kotlin.math.min

class SpeedGaugeView @JvmOverloads constructor(
    context: Context, attrs: AttributeSet? = null
) : View(context, attrs) {

    var speed: Int = 0
        set(v) { field = v; invalidate() }
    var status: String = "Sin GPS"
        set(v) { field = v; invalidate() }
    var unit: String = "km/h"
        set(v) { field = v; invalidate() }
    var arcColor: Int = 0xFFFF8A1F.toInt()
        set(v) { field = v; invalidate() }
    var max: Int = 180
        set(v) { field = v; invalidate() }
    // RPM del OBD. Si es -1, el arco muestra la velocidad.
    var rpm: Int = -1
        set(v) { field = v; invalidate() }

    private val rpmMax = 7000
    private val redFrom = 6000
    private val orange = 0xFFFF8A1F.toInt()
    private val redColor = 0xFFE53935.toInt()

    private val track = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE; color = 0x33FFFFFF; strokeCap = Paint.Cap.ROUND
    }
    private val prog = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE; color = orange; strokeCap = Paint.Cap.ROUND
    }
    private val zone = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE; color = 0x99E53935.toInt(); strokeCap = Paint.Cap.BUTT
    }
    private val big = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = 0xFFFFFFFF.toInt(); textAlign = Paint.Align.CENTER; isFakeBoldText = true
    }
    private val small = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = 0xFFA9AEB5.toInt(); textAlign = Paint.Align.CENTER
    }
    private val rpmText = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = orange; textAlign = Paint.Align.CENTER; isFakeBoldText = true
    }

    override fun onDraw(c: Canvas) {
        val w = width.toFloat()
        val h = height.toFloat()
        val size = min(w, h)
        val stroke = size * 0.07f
        track.strokeWidth = stroke
        prog.strokeWidth = stroke
        zone.strokeWidth = stroke
        val rect = RectF(
            w / 2 - size / 2 + stroke, h / 2 - size / 2 + stroke,
            w / 2 + size / 2 - stroke, h / 2 + size / 2 - stroke
        )
        c.drawArc(rect, 135f, 270f, false, track)

        if (rpm >= 0) {
            // Arco = RPM, con zona roja al final
            c.drawArc(rect, 135f + 270f * redFrom / rpmMax, 270f * (rpmMax - redFrom) / rpmMax, false, zone)
            val sweep = 270f * min(rpm, rpmMax) / rpmMax
            prog.color = if (rpm >= redFrom) redColor else orange
            if (sweep > 0f) c.drawArc(rect, 135f, sweep, false, prog)
        } else {
            // Sin OBD: el arco muestra la velocidad
            val sweep = 270f * min(speed, max) / max.toFloat()
            prog.color = arcColor
            if (sweep > 0f) c.drawArc(rect, 135f, sweep, false, prog)
        }

        big.textSize = size * 0.32f
        c.drawText(speed.toString(), w / 2, h / 2 + size * 0.08f, big)
        small.textSize = size * 0.10f
        c.drawText(unit, w / 2, h / 2 + size * 0.22f, small)
        if (rpm >= 0) {
            rpmText.textSize = size * 0.10f
            c.drawText("$rpm rpm", w / 2, h / 2 + size * 0.34f, rpmText)
        } else {
            small.textSize = size * 0.08f
            c.drawText(status, w / 2, h / 2 + size * 0.33f, small)
        }
    }
}
