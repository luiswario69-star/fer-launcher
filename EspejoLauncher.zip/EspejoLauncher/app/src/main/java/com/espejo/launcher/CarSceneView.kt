package com.espejo.launcher

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.ColorMatrix
import android.graphics.ColorMatrixColorFilter
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RadialGradient
import android.graphics.RectF
import android.graphics.Shader
import android.util.AttributeSet
import android.view.View
import java.util.Random
import kotlin.math.min

// Muestra el carro con un fondo que cambia con el clima, lluvia animada y luces de noche.
class CarSceneView @JvmOverloads constructor(
    context: Context, attrs: AttributeSet? = null
) : View(context, attrs) {

    private val dens = resources.displayMetrics.density
    private var car: Bitmap? = null
    private var isDefault = true

    var night = false
        set(v) { field = v; invalidate() }
    var rain = false
        set(v) { field = v; invalidate() }
    var cloudy = false
        set(v) { field = v; invalidate() }

    // Espacio reservado arriba (textos) y abajo (barra de datos) para que el carro no los tape
    private val insetTop = 82f * dens
    private val insetBottom = 52f * dens

    private val clip = Path()
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val carPaint = Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG)
    private val darkFilter = ColorMatrixColorFilter(ColorMatrix().apply { setScale(0.42f, 0.42f, 0.42f, 1f) })
    private val rnd = Random(7)

    private class Drop(var x: Float, var y: Float, var v: Float, var len: Float)
    private val drops = ArrayList<Drop>()
    private val stars = FloatArray(80) { rnd.nextFloat() }

    fun setCar(bmp: Bitmap?, default: Boolean) {
        car = bmp
        isDefault = default
        invalidate()
    }

    override fun onSizeChanged(w: Int, h: Int, ow: Int, oh: Int) {
        super.onSizeChanged(w, h, ow, oh)
        clip.reset()
        clip.addRoundRect(RectF(0f, 0f, w.toFloat(), h.toFloat()), 20f * dens, 20f * dens, Path.Direction.CW)
        drops.clear()
        for (i in 0 until 70) {
            drops.add(Drop(rnd.nextFloat() * w * 1.2f, rnd.nextFloat() * h,
                (5f + rnd.nextFloat() * 4f) * dens, (10f + rnd.nextFloat() * 8f) * dens))
        }
    }

    private fun glow(c: Canvas, cx: Float, cy: Float, r: Float, color: Int) {
        paint.shader = RadialGradient(cx, cy, r, color, color and 0x00FFFFFF, Shader.TileMode.CLAMP)
        c.drawRect(0f, 0f, width.toFloat(), height.toFloat(), paint)
        paint.shader = null
    }

    override fun onDraw(c: Canvas) {
        val w = width.toFloat()
        val h = height.toFloat()
        c.save()
        c.clipPath(clip)

        // ----- fondo segun clima -----
        paint.style = Paint.Style.FILL
        when {
            night -> {
                c.drawColor(0xFF07080A.toInt())
                paint.color = 0xAAFFFFFF.toInt()
                var i = 0
                while (i < stars.size - 1) {
                    c.drawCircle(stars[i] * w, stars[i + 1] * h * 0.45f, 1.1f * dens, paint)
                    i += 2
                }
                if (!rain) {
                    paint.color = 0xFFE6E8F0.toInt()
                    c.drawCircle(w * 0.86f, h * 0.12f, 9f * dens, paint)
                    paint.color = 0xFF07080A.toInt()
                    c.drawCircle(w * 0.86f + 5f * dens, h * 0.12f - 3f * dens, 8f * dens, paint)
                }
            }
            rain -> {
                c.drawColor(0x66141A22)
                glow(c, w * 0.5f, 0f, w, 0x556E8CAF)
            }
            cloudy -> glow(c, w * 0.5f, 0f, w, 0x44A9AEB5)
            else -> glow(c, w * 0.88f, 0f, w * 0.95f, 0x70FF8A1F)
        }

        // ----- carro -----
        val b = car
        if (b != null) {
            val availW = w - 24f * dens
            val availH = h - insetTop - insetBottom
            val scale = min(availW / b.width, availH / b.height)
            val dw = b.width * scale
            val dh = b.height * scale
            val left = (w - dw) / 2f
            val top = insetTop + (availH - dh) / 2f
            carPaint.colorFilter = if (night) darkFilter else null
            c.drawBitmap(b, null, RectF(left, top, left + dw, top + dh), carPaint)
            if (night && isDefault) drawLights(c, left, top, dw, dh)
        }

        // ----- lluvia -----
        if (rain) {
            paint.style = Paint.Style.STROKE
            paint.strokeWidth = 1.2f * dens
            paint.color = 0x99BED7F0.toInt()
            for (d in drops) {
                c.drawLine(d.x, d.y, d.x - d.len * 0.28f, d.y + d.len, paint)
                d.y += d.v
                d.x -= d.v * 0.28f
                if (d.y > h) { d.y = -d.len; d.x = rnd.nextFloat() * w * 1.2f }
                if (d.x < -20f * dens) d.x += w + 40f * dens
            }
            paint.style = Paint.Style.FILL
            postInvalidateOnAnimation()
        }
        c.restore()
    }

    // Posiciones de los faros como fraccion de la foto predeterminada
    private fun drawLights(c: Canvas, left: Float, top: Float, dw: Float, dh: Float) {
        val lights = arrayOf(floatArrayOf(0.455f, 0.604f, 1f), floatArrayOf(0.052f, 0.497f, 1f), floatArrayOf(0.45f, 0.843f, 0.45f))
        for (l in lights) {
            val lx = left + l[0] * dw
            val ly = top + l[1] * dh
            val k = l[2]
            val len = dw * 0.9f
            val sp = dw * 0.20f
            val beam = Path()
            beam.moveTo(lx, ly)
            beam.lineTo(lx - len, ly + len * 0.30f - sp)
            beam.lineTo(lx - len, ly + len * 0.30f + sp)
            beam.close()
            val a = (0x55 * k).toInt()
            paint.shader = LinearGradient(lx, ly, lx - len, ly + len * 0.3f,
                (a shl 24) or 0xFFECBE, 0x00FFECBE, Shader.TileMode.CLAMP)
            c.drawPath(beam, paint)
            val r = dw * 0.07f
            val a2 = (0xFF * k).toInt()
            paint.shader = RadialGradient(lx, ly, r, (a2 shl 24) or 0xFFF6DC, 0x00FFF6DC, Shader.TileMode.CLAMP)
            c.drawCircle(lx, ly, r, paint)
            paint.shader = null
        }
    }
}
