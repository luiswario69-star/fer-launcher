package com.espejo.launcher

import android.annotation.SuppressLint
import android.bluetooth.BluetoothDevice
import android.bluetooth.BluetoothSocket
import java.io.InputStream
import java.io.OutputStream
import java.util.UUID

// Lector sencillo para adaptadores OBD2 ELM327 por Bluetooth clásico.
class ObdManager(
    private val onData: (Data) -> Unit,
    private val onStatus: (String) -> Unit
) {
    data class Data(val rpm: Int?, val speed: Int?, val coolant: Int?, val fuel: Int?, val volts: String?)

    @Volatile private var running = false
    private var thread: Thread? = null
    @Volatile private var socket: BluetoothSocket? = null
    private val sppUuid = UUID.fromString("00001101-0000-1000-8000-00805F9B34FB")

    fun isRunning() = running

    @SuppressLint("MissingPermission")
    fun start(device: BluetoothDevice) {
        stop()
        running = true
        thread = Thread {
            while (running) {
                try {
                    onStatus("Conectando OBD…")
                    val s = open(device)
                    socket = s
                    val inp = s.inputStream
                    val out = s.outputStream
                    for (cmd in listOf("ATZ", "ATE0", "ATL0", "ATS0", "ATH0", "ATAT1", "ATSP0")) send(out, inp, cmd)
                    onStatus("OBD conectado")
                    var cycle = 0
                    var volts: String? = null
                    while (running) {
                        val rpm = parse(send(out, inp, "010C"), "410C", 2)?.let { (it[0] * 256 + it[1]) / 4 }
                        val speed = parse(send(out, inp, "010D"), "410D", 1)?.get(0)
                        val coolant = if (cycle % 4 == 0) parse(send(out, inp, "0105"), "4105", 1)?.let { it[0] - 40 } else null
                        val fuel = if (cycle % 10 == 0) parse(send(out, inp, "012F"), "412F", 1)?.let { it[0] * 100 / 255 } else null
                        if (cycle % 12 == 0) {
                            val v = send(out, inp, "ATRV")
                            if (v.contains("V")) volts = v.substringBefore("V").takeLast(5) + "V"
                        }
                        onData(Data(rpm, speed, coolant, fuel, volts))
                        cycle++
                    }
                } catch (e: Exception) {
                    if (running) onStatus("OBD sin conexión")
                } finally {
                    closeSocket()
                }
                if (running) {
                    try { Thread.sleep(3000) } catch (_: InterruptedException) {}
                }
            }
        }.also { it.isDaemon = true; it.start() }
    }

    fun stop() {
        running = false
        closeSocket()
        thread = null
    }

    private fun closeSocket() {
        try { socket?.close() } catch (_: Exception) {}
        socket = null
    }

    @SuppressLint("MissingPermission")
    private fun open(device: BluetoothDevice): BluetoothSocket {
        try {
            val s = device.createRfcommSocketToServiceRecord(sppUuid)
            s.connect()
            return s
        } catch (_: Exception) {
            val m = device.javaClass.getMethod("createRfcommSocket", Int::class.javaPrimitiveType)
            val s = m.invoke(device, 1) as BluetoothSocket
            s.connect()
            return s
        }
    }

    private fun send(out: OutputStream, inp: InputStream, cmd: String): String {
        out.write((cmd + "\r").toByteArray())
        out.flush()
        val sb = StringBuilder()
        val end = System.currentTimeMillis() + 3000
        while (System.currentTimeMillis() < end) {
            if (inp.available() > 0) {
                val c = inp.read()
                if (c == '>'.code) break
                sb.append(c.toChar())
            } else {
                Thread.sleep(10)
            }
        }
        return sb.toString().replace("\r", "").replace("\n", "").replace(" ", "")
    }

    private fun parse(resp: String, header: String, n: Int): IntArray? {
        val i = resp.indexOf(header)
        if (i < 0) return null
        val hex = resp.substring(i + header.length)
        if (hex.length < n * 2) return null
        val res = IntArray(n)
        for (k in 0 until n) {
            res[k] = hex.substring(k * 2, k * 2 + 2).toIntOrNull(16) ?: return null
        }
        return res
    }
}
