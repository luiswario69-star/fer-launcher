package com.espejo.launcher

import android.Manifest
import android.annotation.SuppressLint
import android.bluetooth.BluetoothAdapter
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Color
import android.graphics.drawable.Drawable
import android.location.Location
import android.location.LocationListener
import android.location.LocationManager
import android.media.AudioManager
import android.media.MediaMetadata
import android.media.browse.MediaBrowser
import android.media.audiofx.Equalizer
import android.media.session.MediaController
import android.media.session.MediaSessionManager
import android.media.session.PlaybackState
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.provider.Settings
import android.text.InputType
import android.view.LayoutInflater
import android.view.View
import android.view.animation.AlphaAnimation
import android.view.animation.Animation
import android.widget.EditText
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.widget.SwitchCompat
import androidx.core.app.ActivityCompat
import androidx.core.app.NotificationManagerCompat
import androidx.core.content.ContextCompat
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.RecyclerView
import java.io.File
import java.net.HttpURLConnection
import java.net.URL
import java.util.Locale
import kotlin.math.roundToInt
import org.json.JSONObject
import java.util.Calendar

@Suppress("OVERRIDE_DEPRECATION", "DEPRECATION")
class MainActivity : AppCompatActivity(), LocationListener {

    private lateinit var prefs: SharedPreferences
    private lateinit var adapter: AppAdapter
    private lateinit var audio: AudioManager
    private lateinit var gauge: SpeedGaugeView
    private lateinit var carView: CarSceneView
    private lateinit var weatherText: TextView
    private lateinit var musicTime: TextView
    private var weatherAt = 0L
    private var weatherTry = 0L
    private var fetchingWeather = false
    private var hasWeather = false
    private lateinit var tripView: TextView
    private lateinit var greetName: TextView
    private lateinit var greetSub: TextView
    private lateinit var drawer: View
    private lateinit var dock: LinearLayout
    private lateinit var songView: TextView
    private lateinit var artistView: TextView
    private lateinit var artView: ImageView
    private lateinit var playBtn: ImageView
    private lateinit var obdInfo: TextView
    private lateinit var musicSource: TextView
    private var browser: MediaBrowser? = null
    private lateinit var progress: ProgressBar
    private lateinit var volume: SeekBar
    private lateinit var volLabel: TextView
    private lateinit var splash: View
    private lateinit var splashLogo: ImageView
    private lateinit var splashName: TextView

    private val handler = Handler(Looper.getMainLooper())
    private var draggingVolume = false
    private var apps: List<AppInfo> = emptyList()
    private var controller: MediaController? = null
    private var lastLoc: Location? = null
    private var tripM = 0f
    private var lastKmh = 0
    private var speedStatus = "Sin GPS"
    private var obdLiveAt = 0L
    private var lastFuel: Int? = null
    private var lastCoolant: Int? = null
    private var alertLevel = 0
    private var eq: Equalizer? = null
    private var eqApplied = false

    private val musicDefaults = listOf("com.spotify.music", "com.google.android.apps.youtube.music")
    private val navDefaults = listOf("com.google.android.apps.maps", "com.waze")
    private val autoPkg = "com.google.android.projection.gearhead"
    private val mapsPkg = "com.google.android.apps.maps"

    private val pickCar = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) saveImage(uri, "car.png", 1600, true)?.let { carView.setCar(it, false) }
    }
    private val pickLogo = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null && saveImage(uri, "logo.png", 600, true) != null) {
            Toast.makeText(this, "Logo guardado", Toast.LENGTH_SHORT).show()
        }
    }

    private val obd = ObdManager(
        onData = { d -> runOnUiThread { showObd(d) } },
        onStatus = { s -> runOnUiThread { setAlertLevel(0); gauge.rpm = -1; obdInfo.text = s } }
    )

    private val mediaCallback = object : MediaController.Callback() {
        override fun onMetadataChanged(metadata: MediaMetadata?) { updateMedia() }
        override fun onPlaybackStateChanged(state: PlaybackState?) { updateMedia() }
    }
    private val sessionsListener = MediaSessionManager.OnActiveSessionsChangedListener { list ->
        pickController(list)
    }

    private val ticker = object : Runnable {
        override fun run() {
            updateProgress()
            syncVolume()
            if (!hasWeather) carView.night = clockNight()
            maybeFetchWeather()
            handler.postDelayed(this, 1000)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        prefs = getSharedPreferences("launcher", Context.MODE_PRIVATE)
        audio = getSystemService(Context.AUDIO_SERVICE) as AudioManager

        gauge = findViewById(R.id.gauge)
        carView = findViewById(R.id.car)
        weatherText = findViewById(R.id.weatherText)
        musicTime = findViewById(R.id.musicTime)
        findViewById<View>(R.id.btnQueue).setOnClickListener { showQueue() }
        tripView = findViewById(R.id.trip)
        greetName = findViewById(R.id.greetName)
        greetSub = findViewById(R.id.greetSub)
        drawer = findViewById(R.id.drawer)
        dock = findViewById(R.id.dock)
        songView = findViewById(R.id.song)
        artistView = findViewById(R.id.artist)
        artView = findViewById(R.id.art)
        playBtn = findViewById(R.id.play)
        playBtn.setColorFilter(Color.parseColor("#111214"))
        obdInfo = findViewById(R.id.obdInfo)
        musicSource = findViewById(R.id.musicSource)
        musicSource.setOnClickListener { chooseMusicApp() }
        musicSource.setOnLongClickListener { launch(musicPkg()); true }
        progress = findViewById(R.id.progress)
        volume = findViewById(R.id.volume)
        volLabel = findViewById(R.id.volLabel)
        splash = findViewById(R.id.splash)
        splashLogo = findViewById(R.id.splashLogo)
        splashName = findViewById(R.id.splashName)

        greetName.setOnLongClickListener { showProfileMenu(); true }
        greetSub.setOnLongClickListener { showProfileMenu(); true }
        weatherText.setOnLongClickListener { showProfileMenu(); true }

        tripM = prefs.getFloat("trip_m", 0f)
        showTrip()
        tripView.setOnLongClickListener {
            tripM = 0f
            prefs.edit().putFloat("trip_m", 0f).apply()
            showTrip()
            Toast.makeText(this, "Recorrido en cero", Toast.LENGTH_SHORT).show()
            true
        }

        loadCar()
        carView.setOnClickListener { pickCar.launch(arrayOf("image/*")) }
        carView.setOnLongClickListener {
            File(filesDir, "car.png").delete()
            carView.setCar(defaultCar(), true)
            true
        }

        gauge.setOnClickListener {
            prefs.edit().putBoolean("mph", !prefs.getBoolean("mph", false)).apply()
            refreshGauge()
        }

        obdInfo.setOnClickListener { connectObd() }
        obdInfo.setOnLongClickListener { pickObd(); true }

        findViewById<View>(R.id.musicCard).setOnClickListener {
            if (!hasNotifAccess()) openNotifAccess()
        }
        findViewById<View>(R.id.prev).setOnClickListener { controller?.transportControls?.skipToPrevious() }
        findViewById<View>(R.id.next).setOnClickListener { controller?.transportControls?.skipToNext() }
        playBtn.setOnClickListener { togglePlay() }

        findViewById<View>(R.id.chipMaps).setOnClickListener { launch(mapsPkg) }
        findViewById<View>(R.id.chipWaze).setOnClickListener { launch("com.waze") }
        findViewById<View>(R.id.chipHome).apply {
            setOnClickListener { navigateTo("home", "Casa") }
            setOnLongClickListener { askAddress("home", "Casa"); true }
        }
        findViewById<View>(R.id.chipWork).apply {
            setOnClickListener { navigateTo("work", "Trabajo") }
            setOnLongClickListener { askAddress("work", "Trabajo"); true }
        }

        volume.max = audio.getStreamMaxVolume(AudioManager.STREAM_MUSIC)
        volume.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(sb: SeekBar?, p: Int, fromUser: Boolean) {
                if (fromUser) {
                    audio.setStreamVolume(AudioManager.STREAM_MUSIC, p, 0)
                    showVolume(p)
                }
            }
            override fun onStartTrackingTouch(sb: SeekBar?) { draggingVolume = true }
            override fun onStopTrackingTouch(sb: SeekBar?) { draggingVolume = false }
        })
        findViewById<View>(R.id.btnEq).setOnClickListener { showEq() }

        adapter = AppAdapter(
            onClick = { drawer.visibility = View.GONE; launch(it.pkg) },
            onLongClick = { askRole(it) }
        )
        val dm = resources.displayMetrics
        val rows = ((dm.heightPixels / dm.density) / 120).toInt().coerceIn(2, 4)
        findViewById<RecyclerView>(R.id.apps).apply {
            layoutManager = GridLayoutManager(this@MainActivity, rows, RecyclerView.HORIZONTAL, false)
            adapter = this@MainActivity.adapter
        }
        findViewById<View>(R.id.closeDrawer).setOnClickListener { drawer.visibility = View.GONE }

        if (ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION)
            != PackageManager.PERMISSION_GRANTED
        ) {
            ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.ACCESS_FINE_LOCATION), 1)
        }
        if (Build.VERSION.SDK_INT >= 31 && !hasBtPermission()) {
            ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.BLUETOOTH_CONNECT), 2)
        }

        refreshGauge()
        if (savedInstanceState == null) runSplash()
    }

    override fun onResume() {
        super.onResume()
        applyGreeting()
        loadApps()
        renderDock()
        updateSourceLabel()
        startSpeed()
        attachMedia()
        applySavedEq()
        handler.post(ticker)
        if (prefs.getString("obd", null) != null) connectObd()
    }

    override fun onPause() {
        super.onPause()
        handler.removeCallbacks(ticker)
        try {
            (getSystemService(Context.LOCATION_SERVICE) as LocationManager).removeUpdates(this)
        } catch (_: Exception) {}
        detachMedia()
        obd.stop()
    }

    override fun onDestroy() {
        super.onDestroy()
        try { eq?.release() } catch (_: Exception) {}
        try { browser?.disconnect() } catch (_: Exception) {}
    }

    override fun onNewIntent(intent: Intent?) {
        super.onNewIntent(intent)
        drawer.visibility = View.GONE
    }

    override fun onWindowFocusChanged(hasFocus: Boolean) {
        super.onWindowFocusChanged(hasFocus)
        if (hasFocus) {
            window.decorView.systemUiVisibility = (View.SYSTEM_UI_FLAG_FULLSCREEN
                    or View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                    or View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
                    or View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                    or View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                    or View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION)
            window.addFlags(android.view.WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        }
    }

    override fun onBackPressed() {
        if (drawer.visibility == View.VISIBLE) drawer.visibility = View.GONE
    }

    // ---------- Dimensiones ----------

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    // ---------- Saludo, perfil y arranque ----------

    private fun saludo(): String {
        val h = Calendar.getInstance().get(Calendar.HOUR_OF_DAY)
        return if (h < 12) "Buenos días" else if (h < 19) "Buenas tardes" else "Buenas noches"
    }

    private fun applyGreeting() {
        val name = prefs.getString("name", "conductor") ?: "conductor"
        val car = prefs.getString("car", "Toyota Corolla") ?: "Toyota Corolla"
        greetName.text = "Hola, $name"
        greetSub.text = "${saludo()} · $car"
    }

    private fun showProfileMenu() {
        AlertDialog.Builder(this)
            .setTitle("Personalizar")
            .setItems(arrayOf("Cambiar mi nombre", "Cambiar nombre del auto", "Elegir logo de arranque", "Quitar logo de arranque", "Límites de temperatura", "Ajuste de velocidad (%)")) { _, which ->
                when (which) {
                    0 -> askText("Tu nombre", "name", "conductor")
                    1 -> askText("Nombre del auto", "car", "Toyota Corolla")
                    2 -> pickLogo.launch(arrayOf("image/*"))
                    3 -> File(filesDir, "logo.png").delete()
                    4 -> askTempLimits()
                    5 -> askSpeedAdjust()
                }
            }
            .show()
    }

    private fun askSpeedAdjust() {
        val et = EditText(this)
        et.inputType = InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_FLAG_SIGNED
        et.hint = "Ejemplo: 5 marca 5% más, -3 marca 3% menos"
        et.setText(prefs.getInt("speed_adj", 0).toString())
        AlertDialog.Builder(this)
            .setTitle("Ajuste de velocidad (%)")
            .setView(et)
            .setPositiveButton("Guardar") { _, _ ->
                val v = et.text.toString().toIntOrNull()
                if (v != null && v in -30..30) {
                    prefs.edit().putInt("speed_adj", v).apply()
                    refreshGauge()
                } else {
                    Toast.makeText(this, "Pon un número entre -30 y 30", Toast.LENGTH_SHORT).show()
                }
            }
            .setNegativeButton("Cancelar", null)
            .show()
    }

    private fun askTempLimits() {
        val box = LinearLayout(this)
        box.orientation = LinearLayout.VERTICAL
        box.setPadding(dp(20), dp(10), dp(20), dp(10))
        val a = EditText(this)
        a.inputType = InputType.TYPE_CLASS_NUMBER
        a.hint = "Aviso en naranja (°C)"
        a.setText(prefs.getInt("temp_warn", 100).toString())
        val b = EditText(this)
        b.inputType = InputType.TYPE_CLASS_NUMBER
        b.hint = "Alerta roja y parpadeo (°C)"
        b.setText(prefs.getInt("temp_alert", 105).toString())
        box.addView(a)
        box.addView(b)
        AlertDialog.Builder(this)
            .setTitle("Límites de temperatura")
            .setView(box)
            .setPositiveButton("Guardar") { _, _ ->
                val w = a.text.toString().toIntOrNull()
                val t = b.text.toString().toIntOrNull()
                if (w != null && t != null && w < t) {
                    prefs.edit().putInt("temp_warn", w).putInt("temp_alert", t).apply()
                } else {
                    Toast.makeText(this, "El aviso debe ser menor que la alerta", Toast.LENGTH_SHORT).show()
                }
            }
            .setNegativeButton("Cancelar", null)
            .show()
    }

    private fun askText(title: String, key: String, def: String) {
        val et = EditText(this)
        et.setText(prefs.getString(key, def))
        AlertDialog.Builder(this)
            .setTitle(title)
            .setView(et)
            .setPositiveButton("Guardar") { _, _ ->
                val t = et.text.toString().trim()
                if (t.isNotEmpty()) {
                    prefs.edit().putString(key, t).apply()
                    applyGreeting()
                }
            }
            .setNegativeButton("Cancelar", null)
            .show()
    }

    private fun runSplash() {
        val f = File(filesDir, "logo.png")
        if (f.exists()) {
            splashLogo.setImageBitmap(BitmapFactory.decodeFile(f.absolutePath))
            splashLogo.visibility = View.VISIBLE
        } else {
            splashLogo.visibility = View.GONE
        }
        splashName.text = (prefs.getString("car", "Toyota Corolla") ?: "").uppercase()
        val sub = findViewById<View>(R.id.splashSub)
        val bar = findViewById<View>(R.id.splashBar)
        splash.alpha = 1f
        splash.visibility = View.VISIBLE
        splashLogo.alpha = 0f
        splashLogo.scaleX = 0.85f
        splashLogo.scaleY = 0.85f
        splashName.alpha = 0f
        splashName.translationY = 24f
        sub.alpha = 0f
        sub.translationY = 24f
        bar.scaleX = 0f
        splashLogo.animate().alpha(1f).scaleX(1f).scaleY(1f).setDuration(800).start()
        splashName.animate().alpha(1f).translationY(0f).setStartDelay(350).setDuration(600).start()
        bar.animate().scaleX(1f).setStartDelay(600).setDuration(700).start()
        sub.animate().alpha(1f).translationY(0f).setStartDelay(900).setDuration(600).start()
        splash.postDelayed({
            splash.animate().alpha(0f).setDuration(600).withEndAction {
                splash.visibility = View.GONE
                splash.alpha = 1f
            }.start()
        }, 2800)
    }

    // ---------- Imágenes ----------

    private fun loadCar() {
        val f = File(filesDir, "car.png")
        val own = if (f.exists()) BitmapFactory.decodeFile(f.absolutePath) else null
        if (own != null) carView.setCar(own, false) else carView.setCar(defaultCar(), true)
    }

    private fun defaultCar(): Bitmap? = BitmapFactory.decodeResource(resources, R.drawable.car_default)

    private fun saveImage(uri: Uri, name: String, maxW: Int, png: Boolean): Bitmap? {
        try {
            val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
            contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, bounds) }
            var sample = 1
            while (bounds.outWidth / sample > maxW) sample *= 2
            val opts = BitmapFactory.Options().apply { inSampleSize = sample }
            val bmp = contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, opts) }
                ?: return null
            File(filesDir, name).outputStream().use {
                bmp.compress(if (png) Bitmap.CompressFormat.PNG else Bitmap.CompressFormat.JPEG, 90, it)
            }
            return bmp
        } catch (e: Exception) {
            Toast.makeText(this, "No se pudo cargar la imagen", Toast.LENGTH_SHORT).show()
            return null
        }
    }

    // ---------- Apps y barra lateral ----------

    private fun loadApps() {
        val pm = packageManager
        val intent = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        apps = pm.queryIntentActivities(intent, 0)
            .filter { it.activityInfo.packageName != packageName }
            .map { AppInfo(it.loadLabel(pm).toString(), it.activityInfo.packageName, it.loadIcon(pm)) }
            .distinctBy { it.pkg }
            .sortedBy { it.label.lowercase() }
        adapter.submit(apps)
    }

    private fun installed(pkg: String) = apps.any { it.pkg == pkg }

    private fun musicPkg(): String? {
        prefs.getString("music", null)?.takeIf { installed(it) }?.let { return it }
        musicDefaults.firstOrNull { installed(it) }?.let { return it }
        return apps.firstOrNull { it.pkg.contains("youtube.music") || it.label.contains("YouTube Music", true) }?.pkg
    }

    private fun navPkg(): String? =
        prefs.getString("nav", null)?.takeIf { installed(it) } ?: navDefaults.firstOrNull { installed(it) }

    private fun iconOf(pkg: String?) = apps.firstOrNull { it.pkg == pkg }?.icon

    private fun renderDock() {
        dock.removeAllViews()
        val pm = packageManager
        val dialIntent = Intent(Intent.ACTION_DIAL)
        val dialIcon = pm.resolveActivity(dialIntent, 0)?.loadIcon(pm)
        val settingsIntent = Intent(Settings.ACTION_SETTINGS)
        val settingsIcon = pm.resolveActivity(settingsIntent, 0)?.loadIcon(pm)

        addDock("Música", iconOf(musicPkg())) { launch(musicPkg()) }
        addDock("Teléfono", dialIcon) { startActivity(dialIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) }
        addDock("Auto", iconOf(autoPkg)) { launch(autoPkg) }
        addDock("Mapas", iconOf(navPkg())) { launch(navPkg()) }
        addDock("Apps", ContextCompat.getDrawable(this, R.drawable.ic_apps)) { drawer.visibility = View.VISIBLE }
        addDock("Ajustes", settingsIcon) { startActivity(settingsIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) }
    }

    private fun addDock(label: String, icon: Drawable?, action: () -> Unit) {
        val v = LayoutInflater.from(this).inflate(R.layout.item_rail, dock, false)
        v.findViewById<ImageView>(R.id.dIcon).setImageDrawable(icon)
        v.findViewById<TextView>(R.id.dLabel).text = label
        v.setOnClickListener { try { action() } catch (_: Exception) {} }
        dock.addView(v)
    }

    private fun askRole(app: AppInfo) {
        AlertDialog.Builder(this)
            .setTitle(app.label)
            .setItems(arrayOf("Usar como música", "Usar como navegación")) { _, which ->
                prefs.edit().putString(if (which == 0) "music" else "nav", app.pkg).apply()
                renderDock()
            }
            .show()
    }

    private fun launch(pkg: String?) {
        if (pkg == null) return
        packageManager.getLaunchIntentForPackage(pkg)?.let {
            it.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            startActivity(it)
        }
    }

    // ---------- Navegación: Casa y Trabajo ----------

    private fun navigateTo(key: String, title: String) {
        val addr = prefs.getString("addr_$key", null)
        if (addr == null) { askAddress(key, title); return }
        try {
            val i = Intent(Intent.ACTION_VIEW, Uri.parse("google.navigation:q=" + Uri.encode(addr)))
                .setPackage(mapsPkg)
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            startActivity(i)
        } catch (_: Exception) {
            Toast.makeText(this, "No se pudo abrir Google Maps", Toast.LENGTH_SHORT).show()
        }
    }

    private fun askAddress(key: String, title: String) {
        val et = EditText(this)
        et.setText(prefs.getString("addr_$key", ""))
        et.hint = "Calle, número y ciudad"
        AlertDialog.Builder(this)
            .setTitle("Dirección de $title")
            .setView(et)
            .setPositiveButton("Guardar") { _, _ ->
                val t = et.text.toString().trim()
                if (t.isNotEmpty()) prefs.edit().putString("addr_$key", t).apply()
            }
            .setNegativeButton("Cancelar", null)
            .show()
    }

    // ---------- Volumen y ecualizador ----------

    private fun showVolume(p: Int) {
        val max = volume.max.coerceAtLeast(1)
        volLabel.text = "${p * 100 / max}%"
    }

    private fun syncVolume() {
        val cur = audio.getStreamVolume(AudioManager.STREAM_MUSIC)
        if (!draggingVolume) volume.progress = cur
        showVolume(cur)
    }

    private fun ensureEq(): Equalizer? {
        if (eq != null) return eq
        return try { Equalizer(0, 0).also { eq = it } } catch (e: Exception) { null }
    }

    private fun applySavedEq() {
        if (eqApplied || !prefs.getBoolean("eq_on", false)) return
        val e = ensureEq() ?: return
        try {
            val min = e.bandLevelRange[0].toInt()
            for (b in 0 until e.numberOfBands) {
                val lvl = prefs.getInt("eq_$b", Int.MIN_VALUE)
                if (lvl != Int.MIN_VALUE) e.setBandLevel(b.toShort(), lvl.coerceAtLeast(min).toShort())
            }
            e.setEnabled(true)
            eqApplied = true
        } catch (_: Exception) {}
    }

    private fun showEq() {
        val e = ensureEq()
        if (e == null) {
            Toast.makeText(this, "Tu teléfono no permite el ecualizador general. Usa el de tu app de música.", Toast.LENGTH_LONG).show()
            return
        }
        val min = e.bandLevelRange[0].toInt()
        val max = e.bandLevelRange[1].toInt()
        val box = LinearLayout(this)
        box.orientation = LinearLayout.VERTICAL
        box.setPadding(dp(20), dp(10), dp(20), dp(10))

        val sw = SwitchCompat(this)
        sw.text = "Activar ecualizador"
        sw.isChecked = e.getEnabled()
        sw.setOnCheckedChangeListener { _, on ->
            try { e.setEnabled(on) } catch (_: Exception) {}
            prefs.edit().putBoolean("eq_on", on).apply()
        }
        box.addView(sw)

        for (b in 0 until e.numberOfBands) {
            val band = b.toShort()
            val hz = e.getCenterFreq(band) / 1000
            val label = TextView(this)
            label.text = if (hz >= 1000) "${hz / 1000} kHz" else "$hz Hz"
            label.setPadding(0, dp(10), 0, 0)
            box.addView(label)
            val sb = SeekBar(this)
            sb.max = max - min
            sb.progress = e.getBandLevel(band).toInt() - min
            sb.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(s: SeekBar?, p: Int, fromUser: Boolean) {
                    if (fromUser) {
                        try { e.setBandLevel(band, (p + min).toShort()) } catch (_: Exception) {}
                        prefs.edit().putInt("eq_$b", p + min).apply()
                    }
                }
                override fun onStartTrackingTouch(s: SeekBar?) {}
                override fun onStopTrackingTouch(s: SeekBar?) {}
            })
            box.addView(sb)
        }
        val scroll = ScrollView(this)
        scroll.addView(box)
        AlertDialog.Builder(this)
            .setTitle("Ecualizador")
            .setView(scroll)
            .setPositiveButton("Listo", null)
            .show()
    }

    // ---------- Música ----------

    private fun hasNotifAccess() =
        NotificationManagerCompat.getEnabledListenerPackages(this).contains(packageName)

    private fun openNotifAccess() {
        try {
            startActivity(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS))
        } catch (_: Exception) {
            startActivity(Intent(Settings.ACTION_SETTINGS))
        }
    }

    private fun attachMedia() {
        if (!hasNotifAccess()) {
            songView.text = "Activar música"
            artistView.text = "Toca para dar acceso"
            return
        }
        try {
            val msm = getSystemService(Context.MEDIA_SESSION_SERVICE) as MediaSessionManager
            val cn = ComponentName(this, MediaListener::class.java)
            msm.addOnActiveSessionsChangedListener(sessionsListener, cn)
            pickController(msm.getActiveSessions(cn))
        } catch (_: Exception) {}
    }

    private fun detachMedia() {
        try {
            (getSystemService(Context.MEDIA_SESSION_SERVICE) as MediaSessionManager)
                .removeOnActiveSessionsChangedListener(sessionsListener)
        } catch (_: Exception) {}
        controller?.unregisterCallback(mediaCallback)
        controller = null
    }

    private fun pickController(list: List<MediaController>?) {
        controller?.unregisterCallback(mediaCallback)
        val sel = musicPkg()
        controller = list?.firstOrNull { it.packageName == sel && it.playbackState?.state == PlaybackState.STATE_PLAYING }
            ?: list?.firstOrNull { it.playbackState?.state == PlaybackState.STATE_PLAYING }
            ?: list?.firstOrNull { it.packageName == sel }
            ?: list?.firstOrNull()
        controller?.registerCallback(mediaCallback)
        updateMedia()
    }

    private fun updateMedia() {
        val c = controller
        if (c == null) {
            songView.text = "Sin música"
            artistView.text = "Toca para abrir tu app"
            setArt(null)
            playBtn.setImageResource(android.R.drawable.ic_media_play)
            progress.progress = 0
            musicTime.text = "0:00 / 0:00"
            return
        }
        val m = c.metadata
        songView.text = m?.getString(MediaMetadata.METADATA_KEY_TITLE) ?: "Sin título"
        artistView.text = m?.getString(MediaMetadata.METADATA_KEY_ARTIST) ?: ""
        val art = m?.getBitmap(MediaMetadata.METADATA_KEY_ALBUM_ART) ?: m?.getBitmap(MediaMetadata.METADATA_KEY_ART)
        setArt(art)
        val playing = c.playbackState?.state == PlaybackState.STATE_PLAYING
        playBtn.setImageResource(if (playing) android.R.drawable.ic_media_pause else android.R.drawable.ic_media_play)
        updateProgress()
    }

    private fun updateProgress() {
        val c = controller
        val ps = c?.playbackState
        val dur = c?.metadata?.getLong(MediaMetadata.METADATA_KEY_DURATION) ?: 0L
        if (c == null || ps == null || dur <= 0L) { progress.progress = 0; return }
        var pos = ps.position
        if (ps.state == PlaybackState.STATE_PLAYING) {
            pos += ((SystemClock.elapsedRealtime() - ps.lastPositionUpdateTime) * ps.playbackSpeed).toLong()
        }
        pos = pos.coerceIn(0L, dur)
        progress.progress = (pos * 1000 / dur).toInt().coerceIn(0, 1000)
        musicTime.text = fmtTime(pos) + " / " + fmtTime(dur)
    }

    private fun fmtTime(ms: Long): String {
        val s = (ms / 1000).toInt()
        return String.format(Locale.US, "%d:%02d", s / 60, s % 60)
    }

    private fun setArt(bmp: Bitmap?) {
        if (bmp != null) {
            artView.setPadding(0, 0, 0, 0)
            artView.setImageBitmap(bmp)
        } else {
            val p = dp(22)
            artView.setPadding(p, p, p, p)
            artView.setImageResource(R.drawable.ic_music)
        }
    }

    private fun showQueue() {
        val c = controller
        val q = c?.queue
        if (c == null || q == null || q.isEmpty()) {
            Toast.makeText(this, "Tu app de música no comparte la lista de reproducción", Toast.LENGTH_LONG).show()
            return
        }
        val names = q.map {
            val t = it.description.title?.toString() ?: "Sin título"
            val a = it.description.subtitle?.toString()
            if (a.isNullOrEmpty()) t else "$t · $a"
        }.toTypedArray()
        AlertDialog.Builder(this)
            .setTitle("En cola")
            .setItems(names) { _, i -> c.transportControls.skipToQueueItem(q[i].queueId) }
            .show()
    }

    // ---------- Clima ----------

    private fun clockNight(): Boolean {
        val h = Calendar.getInstance().get(Calendar.HOUR_OF_DAY)
        return h < 6 || h >= 19
    }

    @SuppressLint("MissingPermission")
    private fun bestLocation(): Location? {
        lastLoc?.let { return it }
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION)
            != PackageManager.PERMISSION_GRANTED
        ) return null
        return try {
            val lm = getSystemService(Context.LOCATION_SERVICE) as LocationManager
            listOf(LocationManager.GPS_PROVIDER, LocationManager.NETWORK_PROVIDER, LocationManager.PASSIVE_PROVIDER)
                .mapNotNull { try { lm.getLastKnownLocation(it) } catch (_: Exception) { null } }
                .maxByOrNull { it.time }
        } catch (_: Exception) { null }
    }

    private fun maybeFetchWeather() {
        if (fetchingWeather) return
        val now = System.currentTimeMillis()
        if (hasWeather && now - weatherAt < 15 * 60 * 1000L) return
        if (now - weatherTry < 60 * 1000L) return
        val loc = bestLocation() ?: return
        weatherTry = now
        fetchingWeather = true
        val lat = loc.latitude
        val lon = loc.longitude
        Thread {
            try {
                val u = URL(String.format(Locale.US,
                    "https://api.open-meteo.com/v1/forecast?latitude=%.3f&longitude=%.3f&current=temperature_2m,weather_code,is_day&timezone=auto",
                    lat, lon))
                val conn = u.openConnection() as HttpURLConnection
                conn.connectTimeout = 8000
                conn.readTimeout = 8000
                val text = conn.inputStream.bufferedReader().use { it.readText() }
                conn.disconnect()
                val cur = JSONObject(text).getJSONObject("current")
                val temp = cur.getDouble("temperature_2m")
                val code = cur.getInt("weather_code")
                val day = cur.getInt("is_day") == 1
                runOnUiThread { applyWeather(temp, code, day) }
            } catch (_: Exception) {
            } finally {
                fetchingWeather = false
            }
        }.start()
    }

    private fun applyWeather(temp: Double, code: Int, day: Boolean) {
        val isRain = code in 51..67 || code in 80..82 || code in 95..99
        val isSnow = code in 71..77 || code == 85 || code == 86
        val isFog = code == 45 || code == 48
        val cond = when {
            code == 0 -> if (day) "Soleado" else "Despejado"
            code == 1 -> if (day) "Mayormente soleado" else "Mayormente despejado"
            code == 2 -> "Parcialmente nublado"
            code == 3 -> "Nublado"
            isFog -> "Niebla"
            code in 51..57 -> "Llovizna"
            code in 61..67 -> "Lluvia"
            isSnow -> "Nieve"
            code in 80..82 -> "Chubascos"
            code in 95..99 -> "Tormenta"
            else -> ""
        }
        weatherText.text = if (cond.isEmpty()) "${temp.roundToInt()}°" else "${temp.roundToInt()}° · $cond"
        carView.night = !day
        carView.rain = isRain
        carView.cloudy = code in 2..3 || isFog || isSnow
        hasWeather = true
        weatherAt = System.currentTimeMillis()
    }

    private fun updateSourceLabel() {
        val label = apps.firstOrNull { it.pkg == musicPkg() }?.label ?: "Elegir app"
        musicSource.text = "♫ $label ▾"
    }

    private fun musicApps(): List<AppInfo> {
        val svcPkgs = packageManager
            .queryIntentServices(Intent("android.media.browse.MediaBrowserService"), 0)
            .map { it.serviceInfo.packageName }
            .toSet()
        val list = apps.filter { it.pkg in svcPkgs }
        return if (list.isNotEmpty()) list else apps
    }

    private fun chooseMusicApp() {
        val list = musicApps()
        val names = list.map { it.label }.toTypedArray()
        AlertDialog.Builder(this)
            .setTitle("Elige tu app de música")
            .setItems(names) { _, which ->
                prefs.edit().putString("music", list[which].pkg).apply()
                renderDock()
                updateSourceLabel()
                detachMedia()
                attachMedia()
            }
            .show()
    }

    // Intenta darle play a la app elegida sin abrirla (como hace Android Auto)
    private fun startViaBrowser() {
        val pkg = musicPkg()
        if (pkg == null) { chooseMusicApp(); return }
        val svc = packageManager
            .queryIntentServices(Intent("android.media.browse.MediaBrowserService").setPackage(pkg), 0)
            .firstOrNull()?.serviceInfo
        if (svc == null) { launch(pkg); return }
        try { browser?.disconnect() } catch (_: Exception) {}
        val b = MediaBrowser(this, ComponentName(svc.packageName, svc.name),
            object : MediaBrowser.ConnectionCallback() {
                override fun onConnected() {
                    try {
                        val tok = browser?.sessionToken
                        if (tok != null) MediaController(this@MainActivity, tok).transportControls.play()
                    } catch (_: Exception) {}
                    handler.postDelayed({ attachMedia() }, 1500)
                }
                override fun onConnectionFailed() {
                    Toast.makeText(this@MainActivity, "Esa app no permite control externo. Ábrela una vez y dale play.", Toast.LENGTH_LONG).show()
                    launch(pkg)
                }
            }, null)
        browser = b
        b.connect()
    }

    private fun togglePlay() {
        val c = controller
        if (c == null) { startViaBrowser(); return }
        if (c.playbackState?.state == PlaybackState.STATE_PLAYING) c.transportControls.pause()
        else c.transportControls.play()
    }

    // ---------- OBD ----------

    private fun hasBtPermission() = Build.VERSION.SDK_INT < 31 ||
        ContextCompat.checkSelfPermission(this, Manifest.permission.BLUETOOTH_CONNECT) == PackageManager.PERMISSION_GRANTED

    @SuppressLint("MissingPermission")
    private fun connectObd() {
        val addr = prefs.getString("obd", null)
        if (addr == null) { pickObd(); return }
        if (!hasBtPermission()) { obdInfo.text = "Falta permiso Bluetooth"; return }
        val adapter = BluetoothAdapter.getDefaultAdapter()
        if (adapter == null || !adapter.isEnabled) { obdInfo.text = "Activa el Bluetooth"; return }
        if (obd.isRunning()) return
        try {
            obd.start(adapter.getRemoteDevice(addr))
        } catch (e: Exception) {
            obdInfo.text = "OBD error"
        }
    }

    @SuppressLint("MissingPermission")
    private fun pickObd() {
        if (!hasBtPermission()) {
            ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.BLUETOOTH_CONNECT), 2)
            return
        }
        val adapter = BluetoothAdapter.getDefaultAdapter()
        if (adapter == null || !adapter.isEnabled) { obdInfo.text = "Activa el Bluetooth"; return }
        val devices = adapter.bondedDevices.toList()
        if (devices.isEmpty()) {
            Toast.makeText(this, "Primero empareja tu OBD en Ajustes > Bluetooth (clave 1234 o 0000)", Toast.LENGTH_LONG).show()
            return
        }
        val names = devices.map { it.name ?: it.address }.toTypedArray()
        AlertDialog.Builder(this)
            .setTitle("Elige tu OBD")
            .setItems(names) { _, which ->
                prefs.edit().putString("obd", devices[which].address).apply()
                obd.stop()
                connectObd()
            }
            .show()
    }

    private fun showObd(d: ObdManager.Data) {
        if (d.speed != null) {
            obdLiveAt = System.currentTimeMillis()
            lastKmh = d.speed
            speedStatus = "OBD"
            refreshGauge()
        }
        val parts = mutableListOf<String>()
        gauge.rpm = d.rpm ?: -1
        d.rpm?.let { parts.add("$it rpm") }
        d.coolant?.let { lastCoolant = it; parts.add("$it°C") }
        d.volts?.let { parts.add(it) }
        d.fuel?.let { lastFuel = it }
        lastFuel?.let { parts.add("Comb $it%") }
        val t = lastCoolant
        val warn = prefs.getInt("temp_warn", 100)
        val alert = prefs.getInt("temp_alert", 105)
        val level = when {
            t != null && t >= alert -> 2
            t != null && t >= warn -> 1
            else -> 0
        }
        setAlertLevel(level)
        if (level == 2) obdInfo.text = "¡Temperatura alta! $t°C"
        else if (parts.isNotEmpty()) obdInfo.text = parts.joinToString(" · ")
    }

    private fun setAlertLevel(level: Int) {
        if (level == alertLevel) return
        alertLevel = level
        obdInfo.clearAnimation()
        when (level) {
            2 -> {
                obdInfo.setBackgroundResource(R.drawable.pill_alert)
                obdInfo.setTextColor(Color.WHITE)
                val blink = AlphaAnimation(1f, 0.25f)
                blink.duration = 450
                blink.repeatMode = Animation.REVERSE
                blink.repeatCount = Animation.INFINITE
                obdInfo.startAnimation(blink)
            }
            1 -> {
                obdInfo.setBackgroundResource(R.drawable.pill_chip)
                obdInfo.setTextColor(Color.parseColor("#FF8A1F"))
            }
            else -> {
                obdInfo.setBackgroundResource(R.drawable.pill_chip)
                obdInfo.setTextColor(Color.WHITE)
            }
        }
    }

    // ---------- GPS y velocímetro ----------

    private fun refreshGauge() {
        val mph = prefs.getBoolean("mph", false)
        gauge.unit = if (mph) "mph" else "km/h"
        gauge.max = if (mph) 120 else 180
        val adj = prefs.getInt("speed_adj", 0)
        val kmh = (lastKmh * (100 + adj) / 100f).toInt().coerceAtLeast(0)
        gauge.speed = if (mph) (kmh * 0.621371f).toInt() else kmh
        gauge.status = speedStatus
        gauge.arcColor = when {
            kmh > 120 -> 0xFFE53935.toInt()
            kmh > 100 -> 0xFFFF5A1F.toInt()
            else -> 0xFFFF8A1F.toInt()
        }
    }

    private fun showTrip() {
        tripView.text = String.format("%.1f km", tripM / 1000f)
    }

    @SuppressLint("MissingPermission")
    private fun startSpeed() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION)
            != PackageManager.PERMISSION_GRANTED
        ) return
        try {
            val lm = getSystemService(Context.LOCATION_SERVICE) as LocationManager
            lm.requestLocationUpdates(LocationManager.GPS_PROVIDER, 1000L, 0f, this)
        } catch (_: Exception) {}
    }

    override fun onRequestPermissionsResult(code: Int, perms: Array<out String>, results: IntArray) {
        super.onRequestPermissionsResult(code, perms, results)
        startSpeed()
        if (hasBtPermission() && prefs.getString("obd", null) != null) connectObd()
    }

    override fun onLocationChanged(location: Location) {
        val kmh = if (location.hasSpeed()) (location.speed * 3.6f).toInt() else 0
        if (System.currentTimeMillis() - obdLiveAt > 4000) {
            lastKmh = kmh
            speedStatus = "GPS"
            refreshGauge()
        }
        val prev = lastLoc
        if (prev != null && location.accuracy < 40f && kmh > 3) {
            val d = prev.distanceTo(location)
            if (d < 500f) {
                tripM += d
                prefs.edit().putFloat("trip_m", tripM).apply()
                showTrip()
            }
        }
        lastLoc = location
    }

    override fun onStatusChanged(provider: String?, status: Int, extras: Bundle?) {}
    override fun onProviderEnabled(provider: String) {}
    override fun onProviderDisabled(provider: String) {
        lastKmh = 0
        speedStatus = "Sin GPS"
        refreshGauge()
    }
}
